# -SIMPLE-INVENTORY-MANAGEMENT-SYSTEM
This inventory management system helps keep record of stock and price of products in a store. You can also print and view all the items saved in the record.
It also catches any error when you try to put string instead of integer.
